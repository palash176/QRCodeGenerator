import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:scanbot_barcode_sdk_example/network/common_api_service.dart';
import 'package:scanbot_barcode_sdk_example/ui/menu_items.dart';

import 'package:scanbot_image_picker/models/image_picker_response.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';

bool shouldInitWithEncryption = false;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() {
    return _MyAppState();
  }
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MainPageWidget(),
    );
  }
}

class MainPageWidget extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPageWidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text('Barcode SDK Flutter Example App',
            style: TextStyle(inherit: true, color: Colors.black)),
      ),
      body: ListView(
        children: <Widget>[
          MenuItemWidget(
            title: "Single Scan with confirmation dialog",
            onTap: () {
              scanQR();
            },
          ),
        ],
      ),
    );
  }

  Future<void> scanQR() async {
    String barcodeScanRes = 'Unknown';

    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
          '#ff6666', 'Cancel', true, ScanMode.QR);
      if (barcodeScanRes != null) {
        print('barcodeItem');
        print(barcodeScanRes);
        var response =
            await CommonApiService().decrypt({'data': barcodeScanRes});
        print({'data': barcodeScanRes});
        print(response.body);
        try {
          var apiRes = ScannedDataModel.fromJson(json.decode(response.body));
          print(apiRes.toJson());

          // Check for required fields before navigating
          if (apiRes.name != null && apiRes.dob != null) {
            // need to know what mandatory fields  are there
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => DisplayImageScreen(scannedData: apiRes),
              ),
            );
          } else {
            // Show an error message if data is invalid
            showAlertDialog(context, "Invalid QR data");
          }
        } catch (e) {
          showAlertDialog(context, "Error processing QR data");
        }
      }
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    } catch (e) {
      print(e);
    }
    print(barcodeScanRes);
  }

  /// Check for error message and display accordingly.
  void ValidateUriError(ImagePickerResponse response) {
    String message = response.message ?? "";
    showAlertDialog(context, message);
  }
}

Future<void> showAlertDialog(BuildContext context, String textToShow,
    {String? title}) async {
  Widget text = SimpleDialogOption(
    child: Padding(
      padding: const EdgeInsets.all(16.0),
      child: Text(textToShow),
    ),
  );

  // set up the SimpleDialog
  AlertDialog dialog = AlertDialog(
    title: title != null ? Text(title) : null,
    content: text,
    contentPadding: const EdgeInsets.all(0),
    actions: <Widget>[
      TextButton(
        child: const Text('OK'),
        onPressed: () {
          Navigator.of(context).pop();
        },
      ),
    ],
  );

  // show the dialog
  return showDialog<void>(
    context: context,
    builder: (BuildContext context) {
      return dialog;
    },
  );
}

class DisplayImageScreen extends StatelessWidget {
  final ScannedDataModel scannedData;

  // Accepting the ScannedData object as an argument
  DisplayImageScreen({required this.scannedData});

  @override
  Widget build(BuildContext context) {
    // Decode the image from the scanned data
    Uint8List imageBytes = scannedData.decodeImage(scannedData.image);

    return Scaffold(
      appBar: AppBar(title: Text("Scanned Barcode")),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Display the name
              Text("Name: ${scannedData.name}", style: TextStyle(fontSize: 18)),
              SizedBox(height: 8),

              // Display the father's name
              Text("Father's Name: ${scannedData.fatherName}",
                  style: TextStyle(fontSize: 18)),
              SizedBox(height: 8),

              // Display the date of birth
              Text("Date of Birth: ${scannedData.dob}",
                  style: TextStyle(fontSize: 18)),
              SizedBox(height: 8),

              // Display the PAN card number
              Text("PAN Card: ${scannedData.panNumber}",
                  style: TextStyle(fontSize: 18)),
              SizedBox(height: 16),
              SizedBox(
                height: 20,
              ),
              // Display the image from base64 bytes
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Image: ', style: TextStyle(fontSize: 18)),
                  Image.memory(
                    imageBytes,
                    height: 200,
                    width: 200,
                    fit: BoxFit.fill,
                  ),
                ],
              ),

              // Optionally, add any other UI components you'd like to display
            ],
          ),
        ),
      ),
    );
  }
}

class ScannedData {
  final String name;
  final String fatherName;
  final String dob;
  final String panCard;
  String image;

  ScannedData({
    required this.name,
    required this.fatherName,
    required this.dob,
    required this.panCard,
    required this.image,
  });

  // Factory constructor to create a ScannedData object from JSON
  factory ScannedData.fromJson(Map<String, dynamic> json) {
    return ScannedData(
      name: json['name'],
      fatherName: json['fatherName'],
      dob: json['dob'],
      panCard: json['panCard'],
      image: json['image'],
    );
  }

  // Method to convert ScannedData object to JSON
  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'fatherName': fatherName,
      'dob': dob,
      'panCard': panCard,
      'image': image,
    };
  }
}

class ScannedDataModel {
  String? name;
  String? dob;
  String? panNumber;
  String? fatherName;
  String? image;

  ScannedDataModel(
      {this.name, this.dob, this.panNumber, this.fatherName, this.image});

  ScannedDataModel.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    dob = json['dob'];
    panNumber = json['panNumber'];
    fatherName = json['fatherName'];
    image = json['image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['dob'] = this.dob;
    data['panNumber'] = this.panNumber;
    data['fatherName'] = this.fatherName;
    data['image'] = this.image;
    return data;
  }

  // Method to decode the base64 string to image bytes
  Uint8List decodeImage(String? image) {
    if (image == null || image.isEmpty) {
      return Uint8List(0); //empty byte array or placeholder image
    }
    try {
      String base64String = image.split(',').last;
      return base64Decode(base64String);
    } catch (e) {
      print("Error decoding image: $e");
      return Uint8List(0);
    }
  }
}
