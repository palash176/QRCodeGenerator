class ApiEndpoints {
  static const String baseurl = "http://20.215.234.19:8080/";
  static const String decrypt = "qrgenerator/decrypt/data";
}
