import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart';

import 'package:get/get.dart' hide Response;
import '../utils/preference_manager.dart';
import '../utils/utils.dart';
import 'api_endpoints.dart';

class HttpClient {
  HttpClient._privateConstructor();

  static final HttpClient _instance = HttpClient._privateConstructor();

  factory HttpClient() {
    return _instance;
  }

  static Map<String, String> getHeaders() {
    var header = <String, String>{
      "Authorization": "",
      "Accept": "application/json",
      "content-type": "application/json",
    };
    logg.i(header);
    return header;
  }

  Future<Response> getRequest(String path) async {
    Response response;
    try {
      response = await get(
        Uri.parse(ApiEndpoints.baseurl + path),
        headers: getHeaders(),
      ).timeout(const Duration(seconds: 30));
    } on TimeoutException {
      throw TimeoutException('Can\'t connect in 30 seconds.');
    } catch (e) {
      logg.e('Error: $e');
      rethrow;
    }
    logg.i(ApiEndpoints.baseurl + path);
    prettyPrintJson(response.body);

    switch (response.statusCode) {
      case 500:
        {
          Get.snackbar('Error', 'Server Error');
        }
        break;

      case 401:
        {
          Get.snackbar('Error', 'Your Session is Expired, You Need to Login Again.',
              // onTap: (_) => Get.offAllNamed(PageRouteConstants.loginPage)
          );
        }
        break;

      case 200:
        var decode = json.decode(response.body);
        switch (decode['statusCode']) {
          case 500:
            {
              Get.snackbar('Error', decode['message']);
            }
            break;
        }
    }
    return response;
  }

  Future<Response> postRequest(String path, {Map<String, dynamic>? body}) async {
    Response response;
    try {
      response = await post(
        Uri.parse(ApiEndpoints.baseurl + path),
        headers: getHeaders(),
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 30));
    } on TimeoutException {
      throw TimeoutException('Can\'t connect in 30 seconds.');
    } catch (e) {
      logg.e('Error: $e');
      rethrow;
    }

    logg.i(ApiEndpoints.baseurl + path);
    prettyPrintJson(response.body);

    switch (response.statusCode) {
      case 500:
        {
          Get.snackbar('Error', 'Server Error');
        }
        break;

      case 401:
        {
          Get.snackbar('Error', 'Your Session is Expired, You Need to Login Again.',
              // onTap: (_) => Get.offAllNamed(PageRouteConstants.loginPage)
          );
        }
        break;

      case 200:
        var decode = json.decode(response.body);
        switch (decode['statusCode']) {
          case 500:
            {
              Get.snackbar('Error', decode['message']);
            }
            break;
        }
    }
    return response;
  }
}
