import 'package:http/http.dart' as http;
import 'api_endpoints.dart';
import 'http_client.dart';

class CommonApiService {
  CommonApiService._privateConstructor();

  static final CommonApiService _apiServiceInstance = CommonApiService._privateConstructor();

  factory CommonApiService() {
    return _apiServiceInstance;
  }

  final HttpClient _httpClient = HttpClient();

  Future<http.Response> decrypt(Map<String, dynamic> loginReqBody) async {
    return _httpClient.postRequest(ApiEndpoints.decrypt, body: loginReqBody);
  }
}
